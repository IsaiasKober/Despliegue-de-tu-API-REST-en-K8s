﻿namespace linux_prueba.DTO
{
    public class EspecialidadDTO
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public int CarreraId { get; set; }
    }
}
