﻿namespace linux_prueba.DTO
{
    public class CarreraDTO
    {
        public int Id { get; set; }
        public string? Nombre { get; set; }
    }
}
