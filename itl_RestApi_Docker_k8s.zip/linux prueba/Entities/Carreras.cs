﻿namespace linux_prueba.Entities
{
    public partial class Carreras
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
    }
}
